#!/bin/bash
#clolors
white='\e[1;37m'
green='\e[0;32m'
blue='\e[1;34m'
red='\e[1;31m'
yellow='\e[1;33m'
echo ""
echo -e "\e[95m
             ██╗  ██╗ ██████╗ ███████╗████████╗
             ██║  ██║██╔═══██╗██╔════╝╚══██╔══╝
             ███████║██║   ██║███████╗   ██║   
             ██╔══██║██║   ██║╚════██║   ██║   
             ██║  ██║╚██████╔╝███████║   ██║   
             ╚═╝  ╚═╝ ╚═════╝ ╚══════╝   ╚═╝                         
\e[33m                                                              
██████   █████  ██████  ██   ██     ██     ██ ███████ ██████  
██   ██ ██   ██ ██   ██ ██  ██      ██     ██ ██      ██   ██ 
██   ██ ███████ ██████  █████       ██  █  ██ █████   ██████  
██   ██ ██   ██ ██   ██ ██  ██      ██ ███ ██ ██      ██   ██ 
██████  ██   ██ ██   ██ ██   ██      ███ ███  ███████ ██████  \e[0m\n"
echo -e "\e[95m \e[0m\n"
  echo""    
  echo -e $'\e[1;33m\e[0m\e[1;31m    ██████████\e[0m'"\e[1;37m██████████"'\e[1;33m\e[0m\e[0;32m██████████\e[0m' '\e[1;95m\e[0m\e[1;32m Host Daek Website \e[0m''\e[1;37m\e[0m\e[1;37m [v 1.1] \e[0m'                                       
  echo ""
   echo -e $'\e[1;33m\e[0m\e[1;33m  [\e[0m\e[1;32m Github : \e[36mhttps://github.com/astralhacking/HostDarkWebb \e[0m\e[1;32m\e[0m\e[1;33m]\e[0m'
   echo ""
sleep 1
echo ""
echo -e "              \033[1;91m  Author   \033[1;90m:  \033[1;95mAstral Hacking \033[1;97m(SUMAN)"
echo -e "              \033[1;93m Telegram   \033[1;90m: \033[1;96m@hackingastral"
echo -e "              \033[1;92m  Website   \033[1;90m: \033[1;94mwww.onlinehacking.in"
echo -e "              \033[1;97m  Website   \033[1;90m: \033[1;93mwww.onlinehacking.xyz"
echo ""
echo -e ""
sleep 1                                               

