<h1 align="center">
<p> Command : https://termux.xyz/create-your-own-dark-web-onion-website-on-termux/
      </p>
     <br>

</h1>

<h1 align="center">Host Dark Web - OnlineHacking</h1>
<p align="center">
  Create Your Own Dark Web Onion Website on Termux
</p>
<p align="center">
<a href="https://termux.xyz/create-your-own-dark-web-onion-website-on-termux/"><img title="Made in INDIA" src="https://img.shields.io/badge/MADE%20IN-INDIA-SCRIPT?colorA=%23ff8100&colorB=%23017e40&colorC=%23ff0000&style=for-the-badge"></a>
</p>

</p>


<p align="center">
    <img src="https://img.shields.io/badge/Version-1.2-blue?style=for-the-badge&color=blue">
     <img src="https://img.shields.io/github/stars/OnlineHacKing/HostDarkWeb?style=for-the-badge&color=magenta">
  <img src="https://img.shields.io/github/forks/OnlineHacKing/HostDarkWeb?color=cyan&style=for-the-badge&color=purple">
  <img src="https://img.shields.io/github/issues/OnlineHacKing/HostDarkWeb?color=red&style=for-the-badge">
    <img src="https://img.shields.io/github/license/OnlineHacKing/HostDarkWeb?style=for-the-badge&color=blue">
<br>
    <img src="https://img.shields.io/badge/Author-SUMAN-green?style=flat-square">
    <img src="https://img.shields.io/badge/Open%20Source-No-orange?style=flat-square">
    <img src="https://img.shields.io/badge/Maintained-Yes-cyan?style=flat-square">
    <img src="https://img.shields.io/badge/Written%20In-Shell-blue?style=flat-square">
</p>

<p align="center">
<a href="https://termux.xyz/hack-install-free-fire-phishing-tool-with-termux/"><img title="Made in INDIA" src="https://img.shields.io/badge/Tool-HostDarkWeb-green.svg"></a>
<a href="https://termux.xyz/hack-install-free-fire-phishing-tool-with-termux/"><img title="Version" src="https://img.shields.io/badge/Version-1.2-green.svg?style=flat-square"></a>
<a href="https://termux.xyz/hack-install-free-fire-phishing-tool-with-termux/"><img title="Maintainence" src="https://img.shields.io/badge/Admin-SUMAN-green.svg"></a>
</p>

##

<p align="center">

![unnamed (2)](https://raw.githubusercontent.com/OnlineHacKing/HostDarkWeb/main/OnlineHacking/HostDarkWeb.webp)

</p>


##

* `HostOnion Enables Termux users to Host A Hidden Service on TOR with an Onion Address !`
* `This Shell Script uses your device as a server and hosts the webpage on Deepweb Temporarily with an unique onion url`

## Disclaimer
*This tool is for educational purposes only !*<br />
*I will not be responsible for any misuse*

## ☣️ Installation and Usage Guid

### Using Tutorial : https://termux.xyz/create-your-own-dark-web-onion-website-on-termux/
<p><br /></p>

## Note
* `This tool is for termux & linux users only!`


## 💡Pro tip 
* `Replace the HTML file with your own to get your webpage hosted on Deepweb !!`



### 📸 SCREENSHOTS [Termux]

<br>
<p align="center">
<p align="center">
<img width="45%" src="https://github.com/OnlineHacKing/HostDarkWeb/raw/main/OnlineHacking/Create%20Your%20Own%20Dark%20Web%20Onion%20Website%20on%20Termux%20(1).webp"/>
<img width="47%" src="https://github.com/OnlineHacKing/HostDarkWeb/blob/main/OnlineHacking/Create%20Your%20Own%20Dark%20Web%20Onion%20Website%20on%20Termux%20(2).webp?raw=true"/>
</p>




## 👨🏻‍💻 CONNECT WITH US :


<a href="https://github.com/OnlineHacKing"><img title="Github" src="https://img.shields.io/badge/Online-hacking-brightgreen?style=for-the-badge&logo=github"></a>
[![Instagram](https://img.shields.io/badge/INSTAGRAM-FOLLOW-red?style=for-the-badge&logo=instagram)](https://www.instagram.com/suman333mondal/)
[![Instagram](https://img.shields.io/badge/WEBSITE-VISIT-yellow?style=for-the-badge&logo=blogger)](https://www.termux.xyz)
[![Instagram](https://img.shields.io/badge/LINKEDIN-CONNECT-red?style=for-the-badge&logo=linkedin)](https://www.linkedin.com/in/sumam333mondal/)
[![Instagram](https://img.shields.io/badge/FACEBOOK-LIKE-red?style=for-the-badge&logo=facebook)](https://fb.com/onlinehacking)
[![Instagram](https://img.shields.io/badge/TELEGRAM-CHANNEL-red?style=for-the-badge&logo=telegram)](https://telegram.dog/OnlineHacking)
<a href="https://www.youtube.com/@onlinehacking"><img title="YouTube" src="https://img.shields.io/badge/YouTube-Online Hacking-red?style=for-the-badge&logo=Youtube"></a>


# ■□■ ⚠ Warning ⚠ ■□■

***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***

***This information is only for educationla purpose and we are not responsible for any kind of illegal activity done by this tool***


<p style="box-sizing: border-box; color: #24292e; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;; font-size: 16px; margin-bottom: 16px; margin-top: 0px; text-align: center;"><a href="https://github.com/OnlineHacking/" style="background-color: initial; box-sizing: border-box; text-decoration-line: none;"><img alt="GitHub" height="110" src="https://user-images.githubusercontent.com/64035221/96459220-834c7e00-123f-11eb-8417-534058a7ba62.png" style="background-color: var(--color-bg-primary); border-style: none; box-sizing: initial; max-width: 100%;" width="110" />&nbsp;</a><a href="https://www.youtube.com/channel/UC8pmZJAlagdZ7bb0TBlogYw" rel="nofollow" style="background-color: initial; box-sizing: border-box; text-decoration-line: none;"><img alt="YouTube" height="110" src="https://user-images.githubusercontent.com/64035221/96456596-4f238e00-123c-11eb-821e-85e9aaa3faec.png" style="background-color: var(--color-bg-primary); border-style: none; box-sizing: initial; max-width: 100%;" width="110" />&nbsp;</a><a href="https://telegram.dog/OnlineHacking" rel="nofollow" style="background-color: initial; box-sizing: border-box; text-decoration-line: none;"><img alt="Telegram" height="80" src="https://user-images.githubusercontent.com/64035221/96461243-c576bf00-1241-11eb-8fdf-139b4859bfb0.png" style="background-color: var(--color-bg-primary); border-style: none; box-sizing: initial; max-width: 100%;" width="80" />&nbsp;</a><a href="https://www.instagram.com/suman333mondal/" rel="nofollow" style="background-color: initial; box-sizing: border-box; text-decoration-line: none;"><img alt="Instagram" height="90" src="https://user-images.githubusercontent.com/64035221/96461629-3d44e980-1242-11eb-8691-46dd14355085.png" style="background-color: var(--color-bg-primary); border-style: none; box-sizing: initial; max-width: 100%;" width="90" /></a></p>



                     Inspired By github.com/astralhacking

